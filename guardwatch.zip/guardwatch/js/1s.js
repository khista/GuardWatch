

//set id to header navgation menu
let nav = document.querySelector('nav');
nav.setAttribute('id','headNav');

// set id to background image 
let bodyimg = document.querySelector('img');
bodyimg.setAttribute('id','bodyimage');
bodyimg.style.backgroundImage.repeat="no-repeat";










/* //add paragraph
let paragraph = document.createElement('p');
paragraph.innerHTML="Welcome to GuardWatch";
paragraph.style.fontWeight='10em';
paragraph.style.color='green';
document.body.appendChild(paragraph);


// div for menu
let divMenuBar = document.querySelector('div');
divMenuBar.style.background="red";
divMenuBar.style.width='300px;';
divMenuBar.style.height='250px';
  */


/* //header image property 
let headimage = document.querySelector('img');
headimage.style.width="100%";
headimage.style.height="690px";
headimage.style.zIndex='0';
 
headimage.setAttribute('id','headerimage'); */



